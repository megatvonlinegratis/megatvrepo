# -*- coding: utf-8 -*-

# encoded by pyprotect

# https://kodi.tv

# CODIFICADO POR MEGA TV

'''
////////////////////////////////////////
////             © 2020             ////
//// MEGA TV - DIREITOS RESERVADOS ////
////////////////////////////////////////
////   COPIAR É COISA DE MOLEQUE!   ////
//// SE VOCÊ NÃO TEM CAPACIDADE PRA ////
//// CRIAR ALGO PRÓPRIO, PELO MENOS ////
////   RESPEITE O TRABALHO ALHEIO.  ////
////    - TENHA ORIGINALIDADE -     ////
////////////////////////////////////////
'''

_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'==gr0IBh/TTy9/u3yUlNhB0oCKniy2Ah5wda5HX3micZCwVxa59rceXhfUmGBUsbsLxdIGZocVd1CbLuTmioZFNRVEPcjv1HbgGeUOVL2MPKtoNuTgsz0qceGlztGJYN8MC4po36KODSLxoPH89J0m2lMeTPvP9OTTJfaJNRCyPonF2NKXYEwQFWuEJIatCCjDMAUAjgOsUwFwJe'))